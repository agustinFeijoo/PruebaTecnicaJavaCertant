package negocio;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;


public class PokemonEvolutionABM {
	

}
