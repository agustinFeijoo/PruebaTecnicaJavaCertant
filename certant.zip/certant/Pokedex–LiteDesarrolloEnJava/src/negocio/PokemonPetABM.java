package negocio;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import dao.PokemonPetDao;
import datos.PokemonPet;
import datos.Type;

public class PokemonPetABM {
	PokemonPetDao dao = PokemonPetDao.getInstanciaPokemonPetDao();

	public PokemonPet traerPokemonPet(int idPokemonPet) {
		PokemonPet c = dao.traerPokemonPet(idPokemonPet);
		return c;
	}



	public void eliminar(int idPokemonPet) {
		PokemonPet c = dao.traerPokemonPet(idPokemonPet);
		dao.eliminar(c);
	}

	public List<PokemonPet> traerPokemonPet() {
		return dao.traer();
	}
	public void mostrarFilas(HttpServletResponse response) throws IOException{
		
		PokemonPetDao pokemonPetDao=PokemonPetDao.getInstanciaPokemonPetDao(); 
		List<PokemonPet> lstPokemonPet=pokemonPetDao.traer();
		String sClases;//String de clases
		Iterator<PokemonPet> itPp=lstPokemonPet.iterator();//pokemon pet
		Iterator<Type> itType;
		Type type;
		PokemonPet pkPt;
		
		
		
		response.getWriter().append(
				"<thead id='cabeceraTabla'>"//esto podría hacerse con un getContent? sería mas facil con un IFrame?
				+ "<tr>"
					+ "<th>"
						+ "Name"
					+ "</th>"
					+ "<th>"
						+ "Type"
					+ "</th>"
					+ "<th>"
					+ "levelToFound"
					+ "</th>"
					+ "<th>"
					+ "Habilities"
					+ "</th>"
					+ "<th>"
					+ "action"
					+ "</th>"
					+ "</tr>"
					+ "</thead>");
		
		while(itPp.hasNext()) {
			sClases="";//cada vez que cambia de pokemon su cadena de types tambien deberia
			pkPt=(PokemonPet) itPp.next();
			System.out.println(pkPt.getIdPokemon());
			itType=pokemonPetDao.traerPokemonEvolutionYTypes(pkPt.getIdPokemon()).getTypes().iterator();
			
			
			while(itType.hasNext()) {
				type=(Type)itType.next();
				if(itType.hasNext()) {
					sClases=sClases+type.getName()+","; // tomo los nombres de la lista de types de la clase pokemonEvolution
				}else {
					sClases=sClases+type.getName()+".";
				}
			}
			
			response.getWriter().append(
					"<tbody>"
							+ "<tr>"	
								+ "<td id='c1f"+pkPt.getIdPokemonPet()+"'>"+pkPt.getName()+"</td>"
								+ "<td id='c1f"+pkPt.getIdPokemonPet()+"'>"+sClases+"</td>"
								+ "<td id='c1f"+pkPt.getIdPokemonPet()+"'>"+pkPt.getLevelToFound()+"</td>"
								+ "<td id='c1f"+pkPt.getIdPokemonPet()+"'>"+pkPt.getHabilities()+"</td>"
								+"<td><button onclick='modificarPokemonPet("+pkPt.getIdPokemonPet()+")'id='boton"+pkPt.getIdPokemonPet()+ 
								"'>Modificar</button><button onclick='eliminarPokemonPet("+pkPt.getIdPokemonPet()+")'>Eliminar</button></tr>");
			
		}
		response.getWriter().append("</tbody>");
			
		}
		
					
	}


