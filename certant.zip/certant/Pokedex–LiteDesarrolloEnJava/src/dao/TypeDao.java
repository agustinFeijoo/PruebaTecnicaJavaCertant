package dao;

public class TypeDao {

}
