package controladores;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import negocio.PokemonPetABM;

/**
 * Servlet implementation class PokemonPet
 */
@WebServlet("/PokemonPet")
public class PokemonPet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PokemonPet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PokemonPetABM pokemonPetABM=new PokemonPetABM();
		// TODO Auto-generated method stub
		
		if(request.getParameter("borrar")!=null){
		int idCliente=Integer.parseInt(request.getParameter("idCliente"));
		pokemonPetABM.eliminar(idCliente);
		}
		if(request.getParameter("guardar")!=null) {
			long dni=Long.parseLong(request.getParameter("dni"));
			String apellido=request.getParameter("apellido");
			String nombre=request.getParameter("nombre");
			String telefono=request.getParameter("telefono");
			try {
		//		pokemonPetABM.agregar(dni,apellido,nombre,null,null,telefono);
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		//response.getWriter().append("Served at: "+request.getParameter("borrar")).append(request.getContextPath());
		
		if(request.getParameter("mostrar").equals("1")) {
			pokemonPetABM.mostrarFilas(response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	

}
